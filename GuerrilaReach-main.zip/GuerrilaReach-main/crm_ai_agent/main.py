#!/usr/bin/env python3
"""
CRM AI Agent - Main Entry Point

This is the main entry point for the CRM AI Agent application.
"""

import sys
import os
import logging
from typing import Dict, Any

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.utils.config import ConfigManager, EnvironmentConfig
from src.utils.logger import LoggerConfig


def setup_application():
    """Set up the application configuration and logging."""
    try:
        # Load configuration
        config_manager = ConfigManager()
        config = config_manager.load_config()
        
        # Set up logging
        log_level = config.get('log_level', 'INFO')
        LoggerConfig.setup_logging(log_level=log_level)
        
        logger = logging.getLogger(__name__)
        logger.info("CRM AI Agent starting up...")
        logger.info(f"Environment: {EnvironmentConfig.get_environment()}")
        
        return config_manager
        
    except Exception as e:
        print(f"Error setting up application: {e}")
        sys.exit(1)


def run_streamlit_app():
    """Run the Streamlit UI application."""
    try:
        import streamlit as st
        from src.ui.app import CRMStreamlitApp
        
        app = CRMStreamlitApp()
        app.run()
        
    except ImportError:
        print("Streamlit not installed. Install with: pip install streamlit")
        sys.exit(1)
    except Exception as e:
        print(f"Error running Streamlit app: {e}")
        sys.exit(1)


def run_fastapi_app():
    """Run the FastAPI backend application."""
    try:
        import uvicorn
        from src.routes.api import create_app
        
        app = create_app()
        uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
        
    except ImportError:
        print("FastAPI not installed. Install with: pip install fastapi uvicorn")
        sys.exit(1)
    except Exception as e:
        print(f"Error running FastAPI app: {e}")
        sys.exit(1)


def main():
    """Main entry point for the application."""
    import argparse
    
    parser = argparse.ArgumentParser(description="CRM AI Agent")
    parser.add_argument(
        '--mode',
        choices=['ui', 'api', 'both'],
        default='ui',
        help='Application mode: ui (Streamlit), api (FastAPI), or both'
    )
    parser.add_argument(
        '--config',
        help='Path to configuration file'
    )
    
    args = parser.parse_args()
    
    # Set up application
    config_manager = setup_application()
    
    # Run based on mode
    if args.mode == 'ui':
        print("Starting Streamlit UI...")
        run_streamlit_app()
    elif args.mode == 'api':
        print("Starting FastAPI backend...")
        run_fastapi_app()
    elif args.mode == 'both':
        print("Starting both UI and API...")
        # TODO: Implement running both simultaneously
        print("Running both modes not yet implemented")
        sys.exit(1)


if __name__ == "__main__":
    main() 