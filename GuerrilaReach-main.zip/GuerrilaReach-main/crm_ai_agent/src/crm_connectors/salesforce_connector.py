"""
Salesforce CRM Connector

This module provides integration with Salesforce CRM API for lead and contact management.
"""

import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from . import BaseCRMConnector, Lead, Contact


class SalesforceCRMConnector(BaseCRMConnector):
    """Salesforce CRM connector implementation."""
    
    def __init__(self, base_url: str = "https://login.salesforce.com"):
        self.base_url = base_url
        self.access_token = None
        self.instance_url = None
        self.logger = logging.getLogger(__name__)
    
    def authenticate(self, credentials: Dict[str, str]) -> bool:
        """
        Authenticate with Salesforce CRM using OAuth2.
        
        Args:
            credentials: Dictionary containing 'client_id', 'client_secret', 'username', 'password'
            
        Returns:
            bool: True if authentication successful, False otherwise
        """
        try:
            # TODO: Implement proper OAuth2 flow for Salesforce
            # For now, using access token directly
            self.access_token = credentials.get('access_token')
            self.instance_url = credentials.get('instance_url')
            
            if not self.access_token or not self.instance_url:
                self.logger.error("Access token and instance URL not provided")
                return False
            
            # Test authentication by making a simple API call
            headers = self._get_headers()
            response = requests.get(f"{self.instance_url}/services/data/v58.0/sobjects", headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Authentication failed: {e}")
            return False
    
    def _get_headers(self) -> Dict[str, str]:
        """Get headers for Salesforce API requests."""
        return {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
    
    def get_leads(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Lead]:
        """
        Retrieve leads from Salesforce CRM.
        
        Args:
            limit: Maximum number of leads to retrieve
            filters: Dictionary of filters to apply
            
        Returns:
            List of Lead objects
        """
        try:
            headers = self._get_headers()
            
            # Build SOQL query
            query = "SELECT Id, FirstName, LastName, Email, Company, Phone, Status, LeadSource, CreatedDate, LastModifiedDate, Description FROM Lead"
            
            # TODO: Implement proper filter handling for Salesforce
            if filters:
                # Convert filters to SOQL WHERE clause
                pass
            
            if limit:
                query += f" LIMIT {limit}"
            
            params = {'q': query}
            response = requests.get(f"{self.instance_url}/services/data/v58.0/query", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                leads = []
                
                for lead_data in data.get('records', []):
                    lead = Lead(
                        id=lead_data.get('Id'),
                        name=f"{lead_data.get('FirstName', '')} {lead_data.get('LastName', '')}".strip(),
                        email=lead_data.get('Email'),
                        company=lead_data.get('Company'),
                        phone=lead_data.get('Phone'),
                        status=lead_data.get('Status'),
                        source=lead_data.get('LeadSource'),
                        created_date=datetime.fromisoformat(lead_data.get('CreatedDate', '').replace('Z', '+00:00')) if lead_data.get('CreatedDate') else None,
                        last_modified=datetime.fromisoformat(lead_data.get('LastModifiedDate', '').replace('Z', '+00:00')) if lead_data.get('LastModifiedDate') else None,
                        notes=lead_data.get('Description'),
                        custom_fields=lead_data
                    )
                    leads.append(lead)
                
                return leads
            else:
                self.logger.error(f"Failed to retrieve leads: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving leads: {e}")
            return []
    
    def get_contacts(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Contact]:
        """
        Retrieve contacts from Salesforce CRM.
        
        Args:
            limit: Maximum number of contacts to retrieve
            filters: Dictionary of filters to apply
            
        Returns:
            List of Contact objects
        """
        try:
            headers = self._get_headers()
            
            # Build SOQL query
            query = "SELECT Id, FirstName, LastName, Email, Account.Name, Phone, Title, CreatedDate, LastModifiedDate, Description FROM Contact"
            
            if limit:
                query += f" LIMIT {limit}"
            
            params = {'q': query}
            response = requests.get(f"{self.instance_url}/services/data/v58.0/query", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                contacts = []
                
                for contact_data in data.get('records', []):
                    account = contact_data.get('Account', {})
                    contact = Contact(
                        id=contact_data.get('Id'),
                        first_name=contact_data.get('FirstName', ''),
                        last_name=contact_data.get('LastName', ''),
                        email=contact_data.get('Email'),
                        company=account.get('Name') if account else None,
                        phone=contact_data.get('Phone'),
                        title=contact_data.get('Title'),
                        created_date=datetime.fromisoformat(contact_data.get('CreatedDate', '').replace('Z', '+00:00')) if contact_data.get('CreatedDate') else None,
                        last_modified=datetime.fromisoformat(contact_data.get('LastModifiedDate', '').replace('Z', '+00:00')) if contact_data.get('LastModifiedDate') else None,
                        notes=contact_data.get('Description'),
                        custom_fields=contact_data
                    )
                    contacts.append(contact)
                
                return contacts
            else:
                self.logger.error(f"Failed to retrieve contacts: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving contacts: {e}")
            return []
    
    def update_lead(self, lead_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a lead in Salesforce CRM.
        
        Args:
            lead_id: ID of the lead to update
            updates: Dictionary of fields to update
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            headers = self._get_headers()
            
            response = requests.patch(f"{self.instance_url}/services/data/v58.0/sobjects/Lead/{lead_id}", headers=headers, json=updates)
            return response.status_code == 204
            
        except Exception as e:
            self.logger.error(f"Error updating lead: {e}")
            return False
    
    def update_contact(self, contact_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a contact in Salesforce CRM.
        
        Args:
            contact_id: ID of the contact to update
            updates: Dictionary of fields to update
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            headers = self._get_headers()
            
            response = requests.patch(f"{self.instance_url}/services/data/v58.0/sobjects/Contact/{contact_id}", headers=headers, json=updates)
            return response.status_code == 204
            
        except Exception as e:
            self.logger.error(f"Error updating contact: {e}")
            return False
    
    def create_note(self, entity_id: str, note_content: str, entity_type: str = "lead") -> bool:
        """
        Create a note for a lead or contact in Salesforce CRM.
        
        Args:
            entity_id: ID of the lead or contact
            note_content: Content of the note
            entity_type: Type of entity ('lead' or 'contact')
            
        Returns:
            bool: True if note creation successful, False otherwise
        """
        try:
            headers = self._get_headers()
            
            data = {
                "Body": note_content,
                "ParentId": entity_id,
                "Title": "AI Generated Note"
            }
            
            response = requests.post(f"{self.instance_url}/services/data/v58.0/sobjects/Note", headers=headers, json=data)
            return response.status_code == 201
            
        except Exception as e:
            self.logger.error(f"Error creating note: {e}")
            return False
    
    def get_pipeline_stages(self) -> List[str]:
        """
        Get available pipeline stages from Salesforce CRM.
        
        Returns:
            List of pipeline stage names
        """
        try:
            headers = self._get_headers()
            
            # Query for Lead Status picklist values
            query = "SELECT Id, MasterLabel FROM LeadStatus WHERE IsActive = true"
            params = {'q': query}
            response = requests.get(f"{self.instance_url}/services/data/v58.0/query", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                stages = [record.get('MasterLabel', '') for record in data.get('records', [])]
                return stages
            else:
                self.logger.error(f"Failed to retrieve pipeline stages: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving pipeline stages: {e}")
            return [] 