"""
CRM Connectors Module

This module provides interfaces and implementations for connecting to various CRM systems.
Supports Zoho, HubSpot, Salesforce, and other popular CRM platforms.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Lead:
    """Data class representing a lead in any CRM system."""
    id: str
    name: str
    email: str
    company: Optional[str] = None
    phone: Optional[str] = None
    status: Optional[str] = None
    source: Optional[str] = None
    created_date: Optional[datetime] = None
    last_modified: Optional[datetime] = None
    score: Optional[float] = None
    notes: Optional[str] = None
    tags: Optional[List[str]] = None
    custom_fields: Optional[Dict[str, Any]] = None


@dataclass
class Contact:
    """Data class representing a contact in any CRM system."""
    id: str
    first_name: str
    last_name: str
    email: str
    company: Optional[str] = None
    phone: Optional[str] = None
    title: Optional[str] = None
    status: Optional[str] = None
    created_date: Optional[datetime] = None
    last_modified: Optional[datetime] = None
    notes: Optional[str] = None
    tags: Optional[List[str]] = None
    custom_fields: Optional[Dict[str, Any]] = None


class BaseCRMConnector(ABC):
    """Abstract base class for CRM connectors."""
    
    @abstractmethod
    def authenticate(self, credentials: Dict[str, str]) -> bool:
        """Authenticate with the CRM system."""
        pass
    
    @abstractmethod
    def get_leads(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Lead]:
        """Retrieve leads from the CRM."""
        pass
    
    @abstractmethod
    def get_contacts(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Contact]:
        """Retrieve contacts from the CRM."""
        pass
    
    @abstractmethod
    def update_lead(self, lead_id: str, updates: Dict[str, Any]) -> bool:
        """Update a lead in the CRM."""
        pass
    
    @abstractmethod
    def update_contact(self, contact_id: str, updates: Dict[str, Any]) -> bool:
        """Update a contact in the CRM."""
        pass
    
    @abstractmethod
    def create_note(self, entity_id: str, note_content: str, entity_type: str = "lead") -> bool:
        """Create a note for a lead or contact."""
        pass
    
    @abstractmethod
    def get_pipeline_stages(self) -> List[str]:
        """Get available pipeline stages."""
        pass


__all__ = ['BaseCRMConnector', 'Lead', 'Contact'] 