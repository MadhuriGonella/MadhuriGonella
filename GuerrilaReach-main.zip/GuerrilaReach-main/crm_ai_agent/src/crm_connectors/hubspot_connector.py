"""
HubSpot CRM Connector

This module provides integration with HubSpot CRM API for lead and contact management.
"""

import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from . import BaseCRMConnector, Lead, Contact


class HubSpotCRMConnector(BaseCRMConnector):
    """HubSpot CRM connector implementation."""
    
    def __init__(self, base_url: str = "https://api.hubapi.com"):
        self.base_url = base_url
        self.access_token = None
        self.logger = logging.getLogger(__name__)
    
    def authenticate(self, credentials: Dict[str, str]) -> bool:
        """
        Authenticate with HubSpot CRM using API key or OAuth2.
        
        Args:
            credentials: Dictionary containing 'api_key' or 'access_token'
            
        Returns:
            bool: True if authentication successful, False otherwise
        """
        try:
            # Support both API key and OAuth2 access token
            self.access_token = credentials.get('access_token') or credentials.get('api_key')
            if not self.access_token:
                self.logger.error("Access token or API key not provided")
                return False
            
            # Test authentication by making a simple API call
            headers = self._get_headers()
            response = requests.get(f"{self.base_url}/crm/v3/objects/contacts", headers=headers, params={'limit': 1})
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Authentication failed: {e}")
            return False
    
    def _get_headers(self) -> Dict[str, str]:
        """Get headers for HubSpot API requests."""
        return {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
    
    def get_leads(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Lead]:
        """
        Retrieve leads from HubSpot CRM.
        
        Args:
            limit: Maximum number of leads to retrieve
            filters: Dictionary of filters to apply
            
        Returns:
            List of Lead objects
        """
        try:
            headers = self._get_headers()
            
            # Build query parameters
            params = {}
            if limit:
                params['limit'] = limit
            
            # TODO: Implement proper filter handling for HubSpot
            if filters:
                # Convert filters to HubSpot API format
                pass
            
            response = requests.get(f"{self.base_url}/crm/v3/objects/contacts", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                leads = []
                
                for contact_data in data.get('results', []):
                    properties = contact_data.get('properties', {})
                    lead = Lead(
                        id=contact_data.get('id'),
                        name=f"{properties.get('firstname', '')} {properties.get('lastname', '')}".strip(),
                        email=properties.get('email'),
                        company=properties.get('company'),
                        phone=properties.get('phone'),
                        status=properties.get('lifecyclestage'),
                        source=properties.get('lead_source'),
                        created_date=datetime.fromisoformat(contact_data.get('createdAt', '').replace('Z', '+00:00')) if contact_data.get('createdAt') else None,
                        last_modified=datetime.fromisoformat(contact_data.get('updatedAt', '').replace('Z', '+00:00')) if contact_data.get('updatedAt') else None,
                        notes=properties.get('notes'),
                        custom_fields=properties
                    )
                    leads.append(lead)
                
                return leads
            else:
                self.logger.error(f"Failed to retrieve leads: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving leads: {e}")
            return []
    
    def get_contacts(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Contact]:
        """
        Retrieve contacts from HubSpot CRM.
        
        Args:
            limit: Maximum number of contacts to retrieve
            filters: Dictionary of filters to apply
            
        Returns:
            List of Contact objects
        """
        try:
            headers = self._get_headers()
            
            params = {}
            if limit:
                params['limit'] = limit
            
            response = requests.get(f"{self.base_url}/crm/v3/objects/contacts", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                contacts = []
                
                for contact_data in data.get('results', []):
                    properties = contact_data.get('properties', {})
                    contact = Contact(
                        id=contact_data.get('id'),
                        first_name=properties.get('firstname', ''),
                        last_name=properties.get('lastname', ''),
                        email=properties.get('email'),
                        company=properties.get('company'),
                        phone=properties.get('phone'),
                        title=properties.get('jobtitle'),
                        status=properties.get('lifecyclestage'),
                        created_date=datetime.fromisoformat(contact_data.get('createdAt', '').replace('Z', '+00:00')) if contact_data.get('createdAt') else None,
                        last_modified=datetime.fromisoformat(contact_data.get('updatedAt', '').replace('Z', '+00:00')) if contact_data.get('updatedAt') else None,
                        notes=properties.get('notes'),
                        custom_fields=properties
                    )
                    contacts.append(contact)
                
                return contacts
            else:
                self.logger.error(f"Failed to retrieve contacts: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving contacts: {e}")
            return []
    
    def update_lead(self, lead_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a lead in HubSpot CRM.
        
        Args:
            lead_id: ID of the lead to update
            updates: Dictionary of fields to update
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            headers = self._get_headers()
            
            data = {
                "properties": updates
            }
            
            response = requests.patch(f"{self.base_url}/crm/v3/objects/contacts/{lead_id}", headers=headers, json=data)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Error updating lead: {e}")
            return False
    
    def update_contact(self, contact_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a contact in HubSpot CRM.
        
        Args:
            contact_id: ID of the contact to update
            updates: Dictionary of fields to update
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            headers = self._get_headers()
            
            data = {
                "properties": updates
            }
            
            response = requests.patch(f"{self.base_url}/crm/v3/objects/contacts/{contact_id}", headers=headers, json=data)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Error updating contact: {e}")
            return False
    
    def create_note(self, entity_id: str, note_content: str, entity_type: str = "lead") -> bool:
        """
        Create a note for a lead or contact in HubSpot CRM.
        
        Args:
            entity_id: ID of the lead or contact
            note_content: Content of the note
            entity_type: Type of entity ('lead' or 'contact')
            
        Returns:
            bool: True if note creation successful, False otherwise
        """
        try:
            headers = self._get_headers()
            
            data = {
                "properties": {
                    "hs_note_body": note_content,
                    "hs_timestamp": str(int(datetime.now().timestamp() * 1000))
                }
            }
            
            response = requests.post(f"{self.base_url}/crm/v3/objects/notes", headers=headers, json=data)
            return response.status_code == 201
            
        except Exception as e:
            self.logger.error(f"Error creating note: {e}")
            return False
    
    def get_pipeline_stages(self) -> List[str]:
        """
        Get available pipeline stages from HubSpot CRM.
        
        Returns:
            List of pipeline stage names
        """
        try:
            headers = self._get_headers()
            
            response = requests.get(f"{self.base_url}/crm/v3/pipelines/deals", headers=headers)
            
            if response.status_code == 200:
                data = response.json()
                stages = []
                for pipeline in data.get('results', []):
                    for stage in pipeline.get('stages', []):
                        stages.append(stage.get('label', ''))
                return stages
            else:
                self.logger.error(f"Failed to retrieve pipeline stages: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving pipeline stages: {e}")
            return [] 