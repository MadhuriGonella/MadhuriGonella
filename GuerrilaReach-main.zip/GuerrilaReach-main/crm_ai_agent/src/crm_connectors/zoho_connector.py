"""
Zoho CRM Connector

This module provides integration with Zoho CRM API for lead and contact management.
"""

import requests
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from . import BaseCRMConnector, Lead, Contact


class ZohoCRMConnector(BaseCRMConnector):
    """Zoho CRM connector implementation."""
    
    def __init__(self, base_url: str = "https://www.zohoapis.com/crm/v3"):
        self.base_url = base_url
        self.access_token = None
        self.logger = logging.getLogger(__name__)
    
    def authenticate(self, credentials: Dict[str, str]) -> bool:
        """
        Authenticate with Zoho CRM using OAuth2.
        
        Args:
            credentials: Dictionary containing 'client_id', 'client_secret', 'refresh_token'
            
        Returns:
            bool: True if authentication successful, False otherwise
        """
        try:
            # TODO: Implement proper OAuth2 flow for Zoho
            # For now, using access token directly
            self.access_token = credentials.get('access_token')
            if not self.access_token:
                self.logger.error("Access token not provided")
                return False
            
            # Test authentication by making a simple API call
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            response = requests.get(f"{self.base_url}/org", headers=headers)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Authentication failed: {e}")
            return False
    
    def get_leads(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Lead]:
        """
        Retrieve leads from Zoho CRM.
        
        Args:
            limit: Maximum number of leads to retrieve
            filters: Dictionary of filters to apply
            
        Returns:
            List of Lead objects
        """
        try:
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            # Build query parameters
            params = {}
            if limit:
                params['per_page'] = limit
            
            # TODO: Implement proper filter handling
            if filters:
                # Convert filters to Zoho API format
                pass
            
            response = requests.get(f"{self.base_url}/Leads", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                leads = []
                
                for lead_data in data.get('data', []):
                    lead = Lead(
                        id=lead_data.get('id'),
                        name=f"{lead_data.get('First_Name', '')} {lead_data.get('Last_Name', '')}".strip(),
                        email=lead_data.get('Email'),
                        company=lead_data.get('Company'),
                        phone=lead_data.get('Phone'),
                        status=lead_data.get('Lead_Status'),
                        source=lead_data.get('Lead_Source'),
                        created_date=datetime.fromisoformat(lead_data.get('Created_Time', '').replace('Z', '+00:00')) if lead_data.get('Created_Time') else None,
                        last_modified=datetime.fromisoformat(lead_data.get('Modified_Time', '').replace('Z', '+00:00')) if lead_data.get('Modified_Time') else None,
                        notes=lead_data.get('Description'),
                        custom_fields=lead_data
                    )
                    leads.append(lead)
                
                return leads
            else:
                self.logger.error(f"Failed to retrieve leads: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving leads: {e}")
            return []
    
    def get_contacts(self, limit: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> List[Contact]:
        """
        Retrieve contacts from Zoho CRM.
        
        Args:
            limit: Maximum number of contacts to retrieve
            filters: Dictionary of filters to apply
            
        Returns:
            List of Contact objects
        """
        try:
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            params = {}
            if limit:
                params['per_page'] = limit
            
            response = requests.get(f"{self.base_url}/Contacts", headers=headers, params=params)
            
            if response.status_code == 200:
                data = response.json()
                contacts = []
                
                for contact_data in data.get('data', []):
                    contact = Contact(
                        id=contact_data.get('id'),
                        first_name=contact_data.get('First_Name', ''),
                        last_name=contact_data.get('Last_Name', ''),
                        email=contact_data.get('Email'),
                        company=contact_data.get('Account_Name', {}).get('name') if contact_data.get('Account_Name') else None,
                        phone=contact_data.get('Phone'),
                        title=contact_data.get('Title'),
                        status=contact_data.get('Contact_Type'),
                        created_date=datetime.fromisoformat(contact_data.get('Created_Time', '').replace('Z', '+00:00')) if contact_data.get('Created_Time') else None,
                        last_modified=datetime.fromisoformat(contact_data.get('Modified_Time', '').replace('Z', '+00:00')) if contact_data.get('Modified_Time') else None,
                        notes=contact_data.get('Description'),
                        custom_fields=contact_data
                    )
                    contacts.append(contact)
                
                return contacts
            else:
                self.logger.error(f"Failed to retrieve contacts: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving contacts: {e}")
            return []
    
    def update_lead(self, lead_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a lead in Zoho CRM.
        
        Args:
            lead_id: ID of the lead to update
            updates: Dictionary of fields to update
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            data = {
                "data": [{"id": lead_id, **updates}]
            }
            
            response = requests.put(f"{self.base_url}/Leads", headers=headers, json=data)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Error updating lead: {e}")
            return False
    
    def update_contact(self, contact_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a contact in Zoho CRM.
        
        Args:
            contact_id: ID of the contact to update
            updates: Dictionary of fields to update
            
        Returns:
            bool: True if update successful, False otherwise
        """
        try:
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            data = {
                "data": [{"id": contact_id, **updates}]
            }
            
            response = requests.put(f"{self.base_url}/Contacts", headers=headers, json=data)
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Error updating contact: {e}")
            return False
    
    def create_note(self, entity_id: str, note_content: str, entity_type: str = "lead") -> bool:
        """
        Create a note for a lead or contact in Zoho CRM.
        
        Args:
            entity_id: ID of the lead or contact
            note_content: Content of the note
            entity_type: Type of entity ('lead' or 'contact')
            
        Returns:
            bool: True if note creation successful, False otherwise
        """
        try:
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            data = {
                "data": [{
                    "Note_Title": "AI Generated Note",
                    "Note_Content": note_content,
                    "Parent_Id": entity_id,
                    "se_module": entity_type.capitalize()
                }]
            }
            
            response = requests.post(f"{self.base_url}/Notes", headers=headers, json=data)
            return response.status_code == 201
            
        except Exception as e:
            self.logger.error(f"Error creating note: {e}")
            return False
    
    def get_pipeline_stages(self) -> List[str]:
        """
        Get available pipeline stages from Zoho CRM.
        
        Returns:
            List of pipeline stage names
        """
        try:
            headers = {
                'Authorization': f'Zoho-oauthtoken {self.access_token}',
                'Content-Type': 'application/json'
            }
            
            response = requests.get(f"{self.base_url}/settings/pipelines", headers=headers)
            
            if response.status_code == 200:
                data = response.json()
                stages = []
                for pipeline in data.get('pipelines', []):
                    for stage in pipeline.get('stages', []):
                        stages.append(stage.get('display_value', ''))
                return stages
            else:
                self.logger.error(f"Failed to retrieve pipeline stages: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error retrieving pipeline stages: {e}")
            return [] 