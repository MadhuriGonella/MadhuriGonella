"""
Analytics Module

This module provides lead scoring, pipeline analytics, and reporting functionality.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class LeadScore:
    """Data class representing a lead score."""
    lead_id: str
    score: float
    factors: List[str]
    timestamp: datetime
    confidence: float = 0.0


@dataclass
class PipelineMetrics:
    """Data class representing pipeline metrics."""
    total_leads: int
    stage_distribution: Dict[str, int]
    conversion_rates: Dict[str, float]
    average_cycle_time: float
    revenue_pipeline: float
    last_updated: datetime


@dataclass
class AnalyticsReport:
    """Data class representing an analytics report."""
    report_id: str
    report_type: str
    data: Dict[str, Any]
    generated_at: datetime
    insights: List[str]
    recommendations: List[str]


__all__ = ['LeadScore', 'PipelineMetrics', 'AnalyticsReport'] 