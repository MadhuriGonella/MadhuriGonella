"""
AI Prompts Module

This module contains predefined prompts for various AI-powered CRM operations.
"""

from typing import Dict, List, Any


class CRMPrompts:
    """Collection of prompts for CRM operations."""
    
    # Lead Scoring Prompts
    LEAD_SCORING_PROMPT = """
    Analyze the following lead information and provide a comprehensive scoring assessment.
    
    Lead Information:
    - Name: {name}
    - Company: {company}
    - Email: {email}
    - Phone: {phone}
    - Status: {status}
    - Source: {source}
    - Created Date: {created_date}
    - Notes: {notes}
    - Tags: {tags}
    
    Please provide:
    1. A lead score from 0-100 (where 100 is highest priority)
    2. Key factors that influenced the score
    3. Recommendations for next actions
    4. Risk factors to consider
    5. Opportunities to pursue
    
    Format your response as JSON with the following structure:
    {
        "score": <number>,
        "factors": ["factor1", "factor2", ...],
        "recommendations": ["rec1", "rec2", ...],
        "risk_factors": ["risk1", "risk2", ...],
        "opportunities": ["opp1", "opp2", ...],
        "summary": "<brief analysis summary>"
    }
    """
    
    # Outreach Email Generation Prompts
    OUTREACH_EMAIL_PROMPT = """
    Generate a personalized outreach email for the following lead:
    
    Lead Information:
    - Name: {name}
    - Company: {company}
    - Title: {title}
    - Industry: {industry}
    - Source: {source}
    - Previous Interactions: {previous_interactions}
    
    Company Context:
    - Your Company: {your_company}
    - Your Product/Service: {your_product}
    - Value Proposition: {value_proposition}
    
    Requirements:
    - Tone: Professional but friendly
    - Length: 2-3 paragraphs maximum
    - Include a clear call-to-action
    - Personalize based on company/industry
    - Avoid generic templates
    
    Generate:
    1. Email subject line
    2. Email body
    3. Follow-up strategy
    4. Suggested timing for follow-up
    5. Personalization notes
    
    Format as JSON:
    {
        "subject": "<subject line>",
        "body": "<email body>",
        "follow_up_strategy": "<strategy>",
        "timing": "<when to follow up>",
        "personalization_notes": "<notes>"
    }
    """
    
    # Lead Analysis Prompts
    LEAD_ANALYSIS_PROMPT = """
    Perform a comprehensive analysis of this lead for sales prioritization:
    
    Lead Details:
    {lead_details}
    
    Company Research (if available):
    {company_research}
    
    Previous Interactions:
    {interaction_history}
    
    Market Context:
    - Industry trends
    - Company size and growth stage
    - Decision-making timeline indicators
    
    Provide analysis in JSON format:
    {
        "priority_score": <0-100>,
        "urgency_factors": ["factor1", "factor2"],
        "decision_maker_indicators": ["indicator1", "indicator2"],
        "budget_signals": ["signal1", "signal2"],
        "timeline_estimate": "<estimated timeline>",
        "recommended_approach": "<approach strategy>",
        "key_objections_to_address": ["objection1", "objection2"],
        "success_probability": "<high/medium/low>"
    }
    """
    
    # Follow-up Note Generation Prompts
    FOLLOW_UP_NOTE_PROMPT = """
    Generate a professional follow-up note based on the interaction:
    
    Interaction Details:
    - Lead: {lead_name}
    - Company: {company}
    - Interaction Type: {interaction_type}
    - Key Points Discussed: {key_points}
    - Next Steps Agreed: {next_steps}
    - Concerns Raised: {concerns}
    
    Generate a note that:
    1. Summarizes the key discussion points
    2. Documents agreed next steps
    3. Notes any concerns or objections
    4. Sets clear expectations for follow-up
    5. Includes relevant context for future interactions
    
    Format as a professional CRM note.
    """
    
    # Pipeline Optimization Prompts
    PIPELINE_OPTIMIZATION_PROMPT = """
    Analyze the current sales pipeline and provide optimization recommendations:
    
    Pipeline Data:
    {pipeline_data}
    
    Recent Performance:
    {performance_metrics}
    
    Market Conditions:
    {market_context}
    
    Provide recommendations for:
    1. Lead prioritization
    2. Pipeline stage optimization
    3. Resource allocation
    4. Risk mitigation
    5. Opportunity acceleration
    
    Format as JSON:
    {
        "prioritization_recommendations": ["rec1", "rec2"],
        "pipeline_optimizations": ["opt1", "opt2"],
        "resource_allocation": ["alloc1", "alloc2"],
        "risk_mitigation": ["risk1", "risk2"],
        "acceleration_strategies": ["strat1", "strat2"]
    }
    """
    
    # Meeting Preparation Prompts
    MEETING_PREP_PROMPT = """
    Prepare for a meeting with this lead:
    
    Lead Information:
    {lead_info}
    
    Meeting Context:
    - Meeting Type: {meeting_type}
    - Duration: {duration}
    - Attendees: {attendees}
    - Previous Interactions: {previous_interactions}
    
    Company Research:
    {company_research}
    
    Generate:
    1. Key talking points
    2. Questions to ask
    3. Potential objections and responses
    4. Success criteria for the meeting
    5. Follow-up plan
    
    Format as JSON:
    {
        "talking_points": ["point1", "point2"],
        "questions": ["question1", "question2"],
        "objections_responses": {"objection1": "response1"},
        "success_criteria": ["criteria1", "criteria2"],
        "follow_up_plan": "<plan>"
    }
    """
    
    # Lead Qualification Prompts
    LEAD_QUALIFICATION_PROMPT = """
    Qualify this lead based on BANT criteria (Budget, Authority, Need, Timeline):
    
    Lead Information:
    {lead_info}
    
    Interaction History:
    {interaction_history}
    
    Company Information:
    {company_info}
    
    Assess each BANT criterion and provide:
    1. Budget assessment
    2. Authority level identification
    3. Need validation
    4. Timeline evaluation
    5. Overall qualification score
    6. Next qualification steps
    
    Format as JSON:
    {
        "budget": {"score": <0-10>, "assessment": "<assessment>"},
        "authority": {"score": <0-10>, "assessment": "<assessment>"},
        "need": {"score": <0-10>, "assessment": "<assessment>"},
        "timeline": {"score": <0-10>, "assessment": "<assessment>"},
        "overall_score": <0-10>,
        "next_steps": ["step1", "step2"]
    }
    """
    
    @classmethod
    def format_prompt(cls, prompt_template: str, **kwargs) -> str:
        """
        Format a prompt template with provided variables.
        
        Args:
            prompt_template: The prompt template string
            **kwargs: Variables to substitute in the template
            
        Returns:
            Formatted prompt string
        """
        try:
            return prompt_template.format(**kwargs)
        except KeyError as e:
            raise ValueError(f"Missing required variable in prompt: {e}")
        except Exception as e:
            raise ValueError(f"Error formatting prompt: {e}")


class PromptTemplates:
    """Additional prompt templates for specific use cases."""
    
    # Quick Lead Assessment
    QUICK_ASSESSMENT = """
    Quick assessment for lead: {name} at {company}
    Score 0-100 and provide 1-2 key insights.
    """
    
    # Email Personalization
    EMAIL_PERSONALIZATION = """
    Personalize this email for {name} at {company}:
    Industry: {industry}
    Company size: {company_size}
    Recent news: {recent_news}
    
    Original email:
    {original_email}
    """
    
    # Objection Handling
    OBJECTION_HANDLING = """
    Handle this objection from {lead_name}:
    Objection: {objection}
    Context: {context}
    
    Provide a professional, empathetic response.
    """
    
    # Deal Risk Assessment
    DEAL_RISK_ASSESSMENT = """
    Assess risk for deal with {company}:
    Deal value: {deal_value}
    Stage: {stage}
    Timeline: {timeline}
    Competition: {competition}
    
    Identify top 3 risks and mitigation strategies.
    """ 