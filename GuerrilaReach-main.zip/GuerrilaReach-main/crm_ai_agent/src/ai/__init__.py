"""
AI Module

This module provides LLM integration, prompt management, and AI-powered CRM operations.
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime


@dataclass
class AIResponse:
    """Data class representing an AI-generated response."""
    content: str
    confidence: float
    metadata: Optional[Dict[str, Any]] = None
    timestamp: Optional[datetime] = None


@dataclass
class LeadAnalysis:
    """Data class representing AI analysis of a lead."""
    lead_id: str
    score: float
    recommendations: List[str]
    next_actions: List[str]
    risk_factors: List[str]
    opportunities: List[str]
    analysis_summary: str


@dataclass
class OutreachContent:
    """Data class representing AI-generated outreach content."""
    lead_id: str
    email_subject: str
    email_body: str
    follow_up_notes: str
    suggested_timing: str
    personalization_notes: str


__all__ = ['AIResponse', 'LeadAnalysis', 'OutreachContent'] 