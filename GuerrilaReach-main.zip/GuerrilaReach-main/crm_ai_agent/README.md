# CRM AI Agent

An AI-powered CRM agent that automates lead scoring, outreach, and pipeline optimization using machine learning and natural language processing.

## Features

- **Multi-CRM Integration**: Connect to Zoho, HubSpot, Salesforce, and other CRM systems
- **AI-Powered Lead Scoring**: Intelligent lead prioritization using ML algorithms
- **Automated Outreach**: Generate personalized emails and follow-up content
- **Pipeline Analytics**: Real-time pipeline metrics and optimization insights
- **Smart Recommendations**: AI-driven suggestions for next actions and opportunities
- **Memory & Context**: Maintain conversation history and lead context across interactions

## Project Structure

```
crm_ai_agent/
├── src/
│   ├── crm_connectors/     # CRM API integrations
│   │   ├── __init__.py
│   │   ├── zoho_connector.py
│   │   ├── hubspot_connector.py
│   │   └── salesforce_connector.py
│   ├── ai/                 # LLM integration and AI logic
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   ├── prompts.py
│   │   └── memory.py
│   ├── analytics/          # Lead scoring and analytics
│   │   ├── __init__.py
│   │   ├── lead_scoring.py
│   │   └── analytics_utils.py
│   ├── routes/             # API endpoints
│   │   ├── __init__.py
│   │   └── api.py
│   ├── ui/                 # Streamlit UI
│   │   ├── __init__.py
│   │   └── app.py
│   └── utils/              # Shared utilities
│       ├── __init__.py
│       ├── config.py
│       └── logger.py
├── requirements.txt         # Python dependencies
├── env.example             # Example environment variables
└── README.md              # This file
```

## Quick Start

### Prerequisites

- Python 3.9+
- CRM API credentials (Zoho, HubSpot, or Salesforce)
- OpenAI API key (or other LLM provider)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd crm_ai_agent
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment**
   ```bash
   cp env.example .env
   # Edit .env with your API keys and configuration
   ```

5. **Run the application**
   ```bash
   # Streamlit UI
   streamlit run src/ui/app.py
   
   # FastAPI backend
   uvicorn src.routes.api:create_app --reload
   ```

## Configuration

### CRM Setup

1. **Zoho CRM**
   - Get API credentials from Zoho Developer Console
   - Set `CRM_TYPE=zoho` in `.env`
   - Configure `CRM_ACCESS_TOKEN`

2. **HubSpot CRM**
   - Create app in HubSpot Developer Portal
   - Set `CRM_TYPE=hubspot` in `.env`
   - Configure `CRM_API_KEY`

3. **Salesforce CRM**
   - Set up Connected App in Salesforce
   - Set `CRM_TYPE=salesforce` in `.env`
   - Configure OAuth credentials

### AI Configuration

1. **OpenAI**
   - Get API key from OpenAI Platform
   - Set `AI_PROVIDER=openai` in `.env`
   - Configure `OPENAI_API_KEY`

2. **Anthropic**
   - Get API key from Anthropic Console
   - Set `AI_PROVIDER=anthropic` in `.env`
   - Configure `ANTHROPIC_API_KEY`

## Usage

### User Flow

1. **Connect to CRM**: Configure your CRM credentials and test connection
2. **Fetch Leads**: Import leads from your CRM system
3. **Score Leads**: AI analyzes and scores leads based on multiple factors
4. **Generate Insights**: Get AI-powered recommendations for each lead
5. **Create Outreach**: Generate personalized emails and follow-up content
6. **Update CRM**: Sync analysis results and notes back to your CRM

### API Endpoints

- `GET /leads` - Retrieve leads from CRM
- `POST /leads/{id}/analyze` - Analyze specific lead
- `POST /leads/{id}/outreach` - Generate outreach content
- `GET /analytics/pipeline` - Get pipeline metrics
- `POST /analytics/score` - Score all leads

### Streamlit UI

The Streamlit interface provides:
- Dashboard with pipeline overview
- Lead management and scoring
- AI insights and recommendations
- Outreach content generation
- Analytics and reporting

## Development

### Project Structure

The project follows a modular architecture:

- **CRM Connectors**: Abstract interface for different CRM systems
- **AI Module**: LLM integration, prompt management, and memory
- **Analytics**: Lead scoring algorithms and pipeline analytics
- **Routes**: FastAPI endpoints for API access
- **UI**: Streamlit application for user interaction
- **Utils**: Configuration, logging, and shared utilities

### Adding New CRM Connectors

1. Create new connector class inheriting from `BaseCRMConnector`
2. Implement required methods for authentication and data access
3. Add connector to factory pattern in `__init__.py`
4. Update configuration to support new CRM type

### Extending AI Capabilities

1. Add new prompts to `prompts.py`
2. Extend `CRMAIAgent` with new methods
3. Update memory management for new context types
4. Add new analytics for AI insights

### Testing

```bash
# Run tests
pytest

# Run with coverage
pytest --cov=src

# Run specific module
pytest tests/test_crm_connectors.py
```

## Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/new-feature`
3. Make changes and add tests
4. Run tests: `pytest`
5. Commit changes: `git commit -am 'Add new feature'`
6. Push to branch: `git push origin feature/new-feature`
7. Submit pull request

## TODO

### High Priority
- [ ] Implement OAuth2 flows for CRM connectors
- [ ] Add comprehensive error handling and retry logic
- [ ] Implement proper logging and monitoring
- [ ] Add unit tests for all modules
- [ ] Create deployment documentation

### Medium Priority
- [ ] Add support for more CRM systems (Pipedrive, Freshsales)
- [ ] Implement advanced lead scoring algorithms
- [ ] Add real-time notifications and alerts
- [ ] Create mobile-responsive UI
- [ ] Add data export/import functionality

### Low Priority
- [ ] Add multi-language support
- [ ] Implement advanced analytics dashboards
- [ ] Add machine learning model training pipeline
- [ ] Create API rate limiting and caching
- [ ] Add user management and permissions

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue on GitHub
- Check the documentation in `/docs`
- Review the example configurations in `env.example` 