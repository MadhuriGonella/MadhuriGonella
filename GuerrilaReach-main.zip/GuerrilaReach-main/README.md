# AI CRM Agent

An intelligent, AI-powered CRM agent that automates lead scoring, outreach, and pipeline optimization using machine learning and natural language processing. Transform your sales process with automated insights, personalized outreach, and data-driven recommendations.

## 🚀 Features

- **Multi-CRM Integration**: Connect to Zoho, HubSpot, Salesforce, and other CRM systems
- **AI-Powered Lead Scoring**: Intelligent lead prioritization using ML algorithms and LLM analysis
- **Automated Outreach**: Generate personalized emails and follow-up content with AI
- **Pipeline Analytics**: Real-time pipeline metrics and optimization insights
- **Smart Recommendations**: AI-driven suggestions for next actions and opportunities
- **Memory & Context**: Maintain conversation history and lead context across interactions
- **Real-time Insights**: Live dashboard with lead scoring, pipeline health, and AI recommendations

## 🛠 Tech Stack

### Core Technologies
- **Python 3.9+** - Primary programming language
- **FastAPI** - Modern, fast web framework for APIs
- **Streamlit** - Rapid web app development for UI
- **Pydantic** - Data validation and settings management

### AI & Machine Learning
- **OpenAI GPT-4** - Primary LLM for content generation and analysis
- **Anthropic Claude** - Alternative LLM provider
- **LangChain** - LLM application framework
- **Pandas & NumPy** - Data processing and analysis

### CRM Integrations
- **Zoho CRM API** - Zoho CRM integration
- **HubSpot API** - HubSpot CRM integration  
- **Salesforce API** - Salesforce CRM integration
- **Requests** - HTTP library for API calls

### Analytics & Visualization
- **Plotly** - Interactive charts and dashboards
- **Matplotlib** - Static plotting and analytics
- **SQLAlchemy** - Database ORM (optional)

### Development & Testing
- **Pytest** - Testing framework
- **Black** - Code formatting
- **Flake8** - Linting
- **MyPy** - Type checking

## 📁 Project Structure

```
crm_ai_agent/
├── src/
│   ├── crm_connectors/     # CRM API integrations
│   │   ├── __init__.py     # Base classes and interfaces
│   │   ├── zoho_connector.py
│   │   ├── hubspot_connector.py
│   │   └── salesforce_connector.py
│   ├── ai/                 # LLM integration and AI logic
│   │   ├── __init__.py     # Data classes (AIResponse, LeadAnalysis, etc.)
│   │   ├── agent.py        # Main AI agent (CRMAIAgent)
│   │   ├── prompts.py      # Prompt templates and management
│   │   └── memory.py       # Context and memory management
│   ├── analytics/          # Lead scoring and analytics
│   │   ├── __init__.py     # Data classes (LeadScore, PipelineMetrics, etc.)
│   │   ├── lead_scoring.py # Scoring algorithms and engines
│   │   └── analytics_utils.py # Analytics utilities and reporting
│   ├── routes/             # API endpoints
│   │   ├── __init__.py
│   │   └── api.py          # FastAPI routes and handlers
│   ├── ui/                 # Streamlit UI
│   │   ├── __init__.py
│   │   └── app.py          # Streamlit application
│   └── utils/              # Shared utilities
│       ├── __init__.py
│       ├── config.py       # Configuration management
│       └── logger.py       # Logging and audit utilities
├── tests/                  # Test suite (TODO)
├── docs/                   # Documentation (TODO)
├── requirements.txt         # Python dependencies
├── env.example             # Example environment variables
├── .gitignore              # Git ignore file
├── main.py                 # Main entry point
└── README.md              # This file
```

### Module Descriptions

- **`crm_connectors/`**: Abstract interface for CRM systems with concrete implementations for Zoho, HubSpot, and Salesforce
- **`ai/`**: LLM integration, prompt management, AI agent logic, and context memory
- **`analytics/`**: Lead scoring algorithms, pipeline analytics, and reporting utilities
- **`routes/`**: FastAPI REST endpoints for API access and integration
- **`ui/`**: Streamlit web interface for user interaction and dashboard
- **`utils/`**: Configuration management, logging, and shared utilities

## 🚀 Getting Started

### Prerequisites

- **Python 3.9+** installed on your system
- **Git** for version control
- **CRM API credentials** (Zoho, HubSpot, or Salesforce)
- **OpenAI API key** (or other LLM provider)

### 1. Clone the Repository

```bash
git clone <repository-url>
cd crm_ai_agent
```

### 2. Set Up Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Environment Variables

```bash
# Copy example environment file
cp env.example .env

# Edit .env with your API keys and configuration
nano .env  # or use your preferred editor
```

#### Required Environment Variables

```bash
# CRM Configuration
CRM_TYPE=zoho                    # zoho, hubspot, salesforce
CRM_API_KEY=your_crm_api_key
CRM_ACCESS_TOKEN=your_crm_token
CRM_BASE_URL=https://api.crm.com
CRM_CLIENT_ID=your_crm_client_id
CRM_CLIENT_SECRET=your_crm_client_secret

# AI Configuration
AI_PROVIDER=openai               # openai, anthropic, local
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key
AI_MODEL_NAME=gpt-4
AI_TEMPERATURE=0.7
AI_MAX_TOKENS=1000

# Application Configuration
ENVIRONMENT=development          # development, production, testing
DEBUG=true
LOG_LEVEL=INFO
DATA_DIR=./data
CACHE_DIR=./cache
MAX_LEADS_PER_REQUEST=100

# Security
SECRET_KEY=your_secret_key
ENABLE_AUDIT_LOGGING=true
```

### 5. Run the Application

#### Option A: Streamlit UI (Recommended for Development)

```bash
# Run Streamlit UI
streamlit run src/ui/app.py

# Or use the main entry point
python main.py --mode ui
```

#### Option B: FastAPI Backend

```bash
# Run FastAPI backend
uvicorn src.routes.api:create_app --reload --host 0.0.0.0 --port 8000

# Or use the main entry point
python main.py --mode api
```

#### Option C: Both UI and API

```bash
# Run both (in separate terminals)
python main.py --mode ui
python main.py --mode api
```

### 6. Access the Application

- **Streamlit UI**: http://localhost:8501
- **FastAPI Backend**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs

## 📖 Usage

### Step-by-Step Workflow

1. **Connect to CRM**
   - Configure your CRM credentials in `.env`
   - Test connection through the UI or API
   - Verify authentication and permissions

2. **Fetch Leads**
   - Import leads from your CRM system
   - Review lead data and metadata
   - Validate data quality and completeness

3. **Score Leads**
   - AI analyzes leads using multiple factors
   - Review lead scores and confidence levels
   - Understand scoring factors and reasoning

4. **Generate Insights**
   - Get AI-powered recommendations for each lead
   - Review next action suggestions
   - Analyze pipeline optimization opportunities

5. **Create Outreach**
   - Generate personalized emails and content
   - Review and customize AI-generated content
   - Schedule follow-up activities

6. **Update CRM**
   - Sync analysis results back to your CRM
   - Update lead scores and notes
   - Track engagement and outcomes

### API Endpoints

```bash
# Lead Management
GET    /leads                    # Retrieve leads from CRM
GET    /leads/{id}              # Get specific lead
POST   /leads/{id}/analyze      # Analyze specific lead
POST   /leads/{id}/outreach     # Generate outreach content

# Analytics
GET    /analytics/pipeline       # Get pipeline metrics
POST   /analytics/score          # Score all leads
GET    /analytics/reports        # Generate reports

# CRM Operations
POST   /crm/connect             # Test CRM connection
GET    /crm/stages              # Get pipeline stages
POST   /crm/sync                # Sync data with CRM
```

### Streamlit UI Features

- **Dashboard**: Pipeline overview and key metrics
- **Lead Management**: View, filter, and manage leads
- **AI Insights**: AI-generated recommendations and analysis
- **Outreach**: Generate and manage outreach content
- **Analytics**: Pipeline analytics and reporting
- **Settings**: Configuration and CRM setup

## 🤝 Contributing

We welcome contributions! Please follow these guidelines:

### Development Setup

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Set up development environment**
   ```bash
   # Install development dependencies
   pip install -r requirements.txt
   
   # Install pre-commit hooks
   pre-commit install
   ```

### Code Style

We use the following tools for code quality:

```bash
# Format code with Black
black src/ tests/

# Lint with Flake8
flake8 src/ tests/

# Type checking with MyPy
mypy src/

# Run all checks
make lint  # TODO: Create Makefile
```

### Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=html

# Run specific test file
pytest tests/test_crm_connectors.py

# Run tests in parallel
pytest -n auto
```

### Pull Request Process

1. **Create feature branch** from `main`
2. **Make changes** following code style guidelines
3. **Add tests** for new functionality
4. **Update documentation** as needed
5. **Run tests** and ensure they pass
6. **Submit PR** with clear description
7. **Address review comments** promptly

### Branching Model

- `main` - Production-ready code
- `develop` - Integration branch for features
- `feature/*` - New features
- `bugfix/*` - Bug fixes
- `hotfix/*` - Critical production fixes

## 📚 Useful Links

### CRM API Documentation
- [Zoho CRM API](https://www.zoho.com/crm/developer/docs/api/)
- [HubSpot API](https://developers.hubspot.com/docs/api)
- [Salesforce API](https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/)

### AI & LLM Resources
- [OpenAI API Documentation](https://platform.openai.com/docs)
- [Anthropic API Documentation](https://docs.anthropic.com/)
- [LangChain Documentation](https://python.langchain.com/)

### Framework Documentation
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Streamlit Documentation](https://docs.streamlit.io/)
- [Pydantic Documentation](https://docs.pydantic.dev/)

### Development Tools
- [Black Code Formatter](https://black.readthedocs.io/)
- [Flake8 Linter](https://flake8.pycqa.org/)
- [MyPy Type Checker](https://mypy.readthedocs.io/)
- [Pytest Testing Framework](https://docs.pytest.org/)

## 🔧 Troubleshooting

### Common Issues

#### 1. Import Errors
```bash
# Ensure you're in the correct directory
cd crm_ai_agent

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

#### 2. CRM Connection Issues
- Verify API credentials in `.env`
- Check CRM API rate limits
- Ensure proper OAuth2 setup for Salesforce
- Test API endpoints manually

#### 3. AI/LLM Issues
- Verify OpenAI/Anthropic API keys
- Check API quota and billing
- Ensure proper model configuration
- Test API calls independently

#### 4. Streamlit Issues
```bash
# Clear Streamlit cache
streamlit cache clear

# Run with debug mode
streamlit run src/ui/app.py --logger.level debug
```

#### 5. FastAPI Issues
```bash
# Check if port is available
lsof -i :8000

# Run with different port
uvicorn src.routes.api:create_app --port 8001
```

### Getting Help

1. **Check existing issues** on GitHub
2. **Search documentation** in `/docs` (TODO)
3. **Review example configurations** in `env.example`
4. **Create detailed issue** with:
   - Error messages and stack traces
   - Environment details
   - Steps to reproduce
   - Expected vs actual behavior

### Support Channels

- **GitHub Issues**: For bugs and feature requests
- **Documentation**: `/docs` folder (TODO)
- **Discussions**: GitHub Discussions (TODO)
- **Email**: [TODO: Add support email]

## 📋 TODO

### High Priority
- [ ] Implement OAuth2 flows for CRM connectors
- [ ] Add comprehensive test suite
- [ ] Create deployment documentation
- [ ] Add database persistence layer
- [ ] Implement proper error handling and retry logic

### Medium Priority
- [ ] Add support for more CRM systems (Pipedrive, Freshsales)
- [ ] Create advanced analytics dashboards
- [ ] Add real-time notifications
- [ ] Implement user management and permissions
- [ ] Add data export/import functionality

### Low Priority
- [ ] Add multi-language support
- [ ] Create mobile-responsive UI
- [ ] Add machine learning model training pipeline
- [ ] Implement API rate limiting and caching
- [ ] Add advanced security features

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- OpenAI for GPT-4 API
- Streamlit for the web app framework
- FastAPI for the modern API framework
- All contributors and maintainers

---

**Happy coding! 🚀**

For questions or support, please [create an issue](https://github.com/your-repo/issues) or check our [documentation](docs/).
